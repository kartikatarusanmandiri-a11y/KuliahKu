KULIAHKU — MODE LAYAR UTAMA ANDROID

Project ini sudah ditambahkan kategori Android HOME/DEFAULT. Setelah APK terpasang, Android dapat menawarkan KuliahKu sebagai aplikasi Layar Utama/Home.

Cara memakai:
1. Build dan instal app-debug.apk.
2. Tekan tombol Home pada HP.
3. Jika muncul pilihan aplikasi Layar Utama, pilih KuliahKu.
4. Pilih “Selalu” jika ingin KuliahKu menjadi Home default.

Untuk mengembalikan launcher bawaan, buka Pengaturan Android > Aplikasi > Aplikasi default > Aplikasi Beranda/Layar utama, lalu pilih launcher bawaan. Nama menu dapat berbeda menurut merek HP.

Catatan: ini menjadikan KuliahKu sebagai HOME launcher, bukan sekadar ikon di layar utama. Fungsi HTML tetap dipakai. Embedded Zoom dan screen sharing tetap bergantung pada dukungan Android WebView dan backend signature Zoom yang digunakan oleh HTML.
