KULIAHKU APK - TANPA ANDROID STUDIO

File index.html adalah HTML KuliahKu yang diberikan pengguna dan dimasukkan ke assets tanpa mengubah isi/fungsi HTML.

Cara build tanpa Android Studio:
1. Upload folder proyek ini ke repository GitHub.
2. Buka tab Actions.
3. Pilih workflow "Build KuliahKu APK".
4. Klik Run workflow.
5. Setelah selesai, buka Artifacts dan unduh "KuliahKu-debug-apk".
6. Install APK di Android.

Catatan:
- WebView mengaktifkan JavaScript, localStorage, database/IndexedDB, kamera/mikrofon, dan pemilih file agar fungsi HTML tetap berjalan.
- PDF dan foto dipilih melalui file chooser Android.
- Link web/Zoom eksternal dapat dibuka melalui aplikasi browser/Zoom.
- APK debug ini belum ditandatangani untuk Play Store.
- Fungsi yang membutuhkan backend seperti /api/zoom/signature tetap membutuhkan server backend yang sesuai; membungkus HTML menjadi APK tidak membuat endpoint tersebut otomatis tersedia.
