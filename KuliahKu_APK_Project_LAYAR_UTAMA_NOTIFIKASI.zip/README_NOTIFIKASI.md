# KuliahKu 1.1 — Notifikasi Pengingat Jadwal

Versi ini menambahkan notifikasi Android native untuk jadwal kuliah.

Fitur:
- Aktif/nonaktif pengingat kuliah.
- Pilihan 5, 10, 15, 30, atau 60 menit sebelum kuliah.
- Pengingat dijadwalkan berdasarkan jadwal kuliah yang ada di `index.html`.
- Notifikasi tetap dapat muncul ketika aplikasi tidak sedang dibuka.
- Jadwal pengingat dijadwalkan ulang setelah HP restart.
- Menu Pengingat tersedia di Beranda dan sidebar.
- Pengaturan notifikasi Android dapat dibuka dari aplikasi.

Catatan:
- Notifikasi Android native aktif setelah project ini dibuild dan dipasang sebagai APK.
- Android 13+ meminta izin notifikasi.
- Pengingat menggunakan AlarmManager `setAndAllowWhileIdle`; waktu dapat sedikit bergeser pada perangkat yang sangat agresif menghemat baterai.
