package com.kuliahku.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    private static final int FILE_CHOOSER = 1001;
    private static final int PERMISSIONS = 1002;
    private static final int NOTIFICATION_PERMISSION = 1003;
    private ValueCallback<Uri[]> uploadCallback;

    public static final String CHANNEL_ID = "kuliahku_jadwal";
    public static final String PREFS = "kuliahku_notifications";
    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_MINUTES = "minutes";
    public static final String KEY_SCHEDULE = "schedule_json";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        NotificationHelper.createChannel(this);

        webView = new WebView(this);
        setContentView(webView);

        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[] {
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO
            }, PERMISSIONS);
        }
        if (Build.VERSION.SDK_INT >= 33 &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                        != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
        }

        WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new NotificationBridge(this), "KuliahKuAndroid");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String scheme = u.getScheme();
                if ("http".equalsIgnoreCase(scheme) || "https".equalsIgnoreCase(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, u));
                        return true;
                    } catch (Exception ignored) {}
                }
                return false;
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, android.os.Message resultMsg) {
                WebView.HitTestResult r = view.getHitTestResult();
                String url = r != null ? r.getExtra() : null;
                if (url != null) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
                    catch (Exception ignored) {}
                }
                return false;
            }

            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> filePathCallback,
                                             FileChooserParams fileChooserParams) {
                if (uploadCallback != null) uploadCallback.onReceiveValue(null);
                uploadCallback = filePathCallback;
                Intent intent = fileChooserParams.createIntent();
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                try {
                    startActivityForResult(intent, FILE_CHOOSER);
                } catch (Exception e) {
                    uploadCallback = null;
                    return false;
                }
                return true;
            }
        });

        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            if (uploadCallback == null) return;
            Uri[] result = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    result = new Uri[n];
                    for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            uploadCallback.onReceiveValue(result);
            uploadCallback = null;
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public static class NotificationBridge {
        private final Context context;
        NotificationBridge(Context context) { this.context = context.getApplicationContext(); }

        @JavascriptInterface
        public boolean isAvailable() { return true; }

        @JavascriptInterface
        public boolean isEnabled() {
            return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false);
        }

        @JavascriptInterface
        public int getMinutes() {
            return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_MINUTES, 30);
        }

        @JavascriptInterface
        public void setEnabled(boolean enabled) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ENABLED, enabled).apply();
            if (!enabled) AlarmScheduler.cancelAll(context);
        }

        @JavascriptInterface
        public void setMinutes(int minutes) {
            if (minutes < 5) minutes = 5;
            if (minutes > 60) minutes = 60;
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_MINUTES, minutes).apply();
        }

        @JavascriptInterface
        public void scheduleWeekly(String json) {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                    .putString(KEY_SCHEDULE, json)
                    .apply();
            if (isEnabled()) AlarmScheduler.schedule(context, json, getMinutes());
        }

        @JavascriptInterface
        public void reschedule() {
            String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(KEY_SCHEDULE, "[]");
            if (isEnabled()) AlarmScheduler.schedule(context, json, getMinutes());
            else AlarmScheduler.cancelAll(context);
        }

        @JavascriptInterface
        public void openNotificationSettings() {
            try {
                Intent i = new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS);
                i.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, context.getPackageName());
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(i);
            } catch (Exception ignored) {}
        }
    }

    public static class AlarmScheduler {
        private static final String ACTION = "com.kuliahku.app.CLASS_REMINDER";
        private static final int BASE = 42000;

        static void schedule(Context context, String json, int reminderMinutes) {
            cancelAll(context);
            try {
                JSONArray arr = new JSONArray(json);
                Set<Integer> used = new HashSet<>();
                for (int i = 0; i < arr.length(); i++) {
                    JSONObject j = arr.getJSONObject(i);
                    String day = j.optString("hari", "");
                    String time = j.optString("mulai", "");
                    if (day.isEmpty() || time.isEmpty()) continue;
                    int dayOfWeek = dayToCalendar(day);
                    String[] parts = time.split(":");
                    if (parts.length != 2) continue;
                    int hour = Integer.parseInt(parts[0]);
                    int minute = Integer.parseInt(parts[1]);
                    int id = BASE + Math.abs((day + "|" + time + "|" + j.optString("matkul","")).hashCode() % 1000000);
                    while (used.contains(id)) id++;
                    used.add(id);
                    scheduleOne(context, id, dayOfWeek, hour, minute, reminderMinutes,
                            j.optString("matkul","Kuliah"),
                            j.optString("ruang",""),
                            j.optString("dosen",""));
                }
            } catch (Exception ignored) {}
        }

        static void scheduleOne(Context context, int requestCode, int dayOfWeek, int hour, int minute,
                                int reminderMinutes, String matkul, String ruang, String dosen) {
            Calendar now = Calendar.getInstance();
            Calendar classTime = Calendar.getInstance();
            classTime.set(Calendar.SECOND, 0);
            classTime.set(Calendar.MILLISECOND, 0);
            classTime.set(Calendar.HOUR_OF_DAY, hour);
            classTime.set(Calendar.MINUTE, minute);
            int diff = dayOfWeek - now.get(Calendar.DAY_OF_WEEK);
            if (diff < 0) diff += 7;
            if (diff == 0 && classTime.getTimeInMillis() <= now.getTimeInMillis()) diff = 7;
            classTime.add(Calendar.DAY_OF_YEAR, diff);
            classTime.add(Calendar.MINUTE, -reminderMinutes);
            if (classTime.getTimeInMillis() <= System.currentTimeMillis()) classTime.add(Calendar.DAY_OF_YEAR, 7);

            Intent intent = new Intent(context, ReminderReceiver.class);
            intent.setAction(ACTION);
            intent.putExtra("requestCode", requestCode);
            intent.putExtra("matkul", matkul);
            intent.putExtra("ruang", ruang);
            intent.putExtra("dosen", dosen);
            intent.putExtra("hour", hour);
            intent.putExtra("minute", minute);
            intent.putExtra("dayOfWeek", dayOfWeek);
            intent.putExtra("reminderMinutes", reminderMinutes);

            PendingIntent pi = PendingIntent.getBroadcast(context, requestCode, intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am != null) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, classTime.getTimeInMillis(), pi);
            }
        }

        static void cancelAll(Context context) {
            AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
            if (am == null) return;
            // Cancel alarms by rebuilding from saved schedule.
            String json = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .getString(KEY_SCHEDULE, "[]");
            try {
                JSONArray arr = new JSONArray(json);
                for (int i=0;i<arr.length();i++) {
                    JSONObject j=arr.getJSONObject(i);
                    int id=BASE + Math.abs((j.optString("hari","") + "|" + j.optString("mulai","") + "|" +
                            j.optString("matkul","")).hashCode() % 1000000);
                    Intent intent = new Intent(context, ReminderReceiver.class);
                    intent.setAction(ACTION);
                    PendingIntent pi=PendingIntent.getBroadcast(context,id,intent,
                            PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                    am.cancel(pi);
                    pi.cancel();
                }
            } catch(Exception ignored) {}
        }

        static int dayToCalendar(String day) {
            switch(day) {
                case "Minggu": return Calendar.SUNDAY;
                case "Senin": return Calendar.MONDAY;
                case "Selasa": return Calendar.TUESDAY;
                case "Rabu": return Calendar.WEDNESDAY;
                case "Kamis": return Calendar.THURSDAY;
                case "Jumat": return Calendar.FRIDAY;
                default: return Calendar.SATURDAY;
            }
        }
    }

    public static class NotificationHelper {
        static void createChannel(Context context) {
            if (Build.VERSION.SDK_INT >= 26) {
                NotificationChannel c = new NotificationChannel(
                        CHANNEL_ID, "Pengingat Kuliah", NotificationManager.IMPORTANCE_HIGH);
                c.setDescription("Pengingat jadwal kuliah KuliahKu");
                c.enableVibration(true);
                NotificationManager nm = context.getSystemService(NotificationManager.class);
                if (nm != null) nm.createNotificationChannel(c);
            }
        }

        static void show(Context context, String matkul, String ruang, String dosen, int requestCode) {
            createChannel(context);
            String text = "Kuliah segera dimulai" + (ruang.isEmpty() ? "" : " · Ruang " + ruang);
            NotificationCompat.Builder b = new NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("🔔 " + matkul)
                    .setContentText(text)
                    .setStyle(new NotificationCompat.BigTextStyle().bigText(
                            text + (dosen.isEmpty() ? "" : "\nDosen: " + dosen)))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setAutoCancel(true)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER);
            if (Build.VERSION.SDK_INT < 33 ||
                    ActivityCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                            == PackageManager.PERMISSION_GRANTED) {
                NotificationManagerCompat.from(context).notify(requestCode, b.build());
            }
        }
    }
}
