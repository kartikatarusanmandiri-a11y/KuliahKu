package com.kuliahku.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) {
            if (context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                    .getBoolean(MainActivity.KEY_ENABLED, false)) {
                String json=context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                        .getString(MainActivity.KEY_SCHEDULE, "[]");
                int mins=context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                        .getInt(MainActivity.KEY_MINUTES, 30);
                MainActivity.AlarmScheduler.schedule(context,json,mins);
            }
        }
    }
}
