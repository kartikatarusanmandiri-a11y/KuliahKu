package com.kuliahku.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import org.json.JSONArray;
import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        if (!MainActivity.NotificationBridge.class.equals(MainActivity.NotificationBridge.class)) {}
        String matkul=intent.getStringExtra("matkul");
        String ruang=intent.getStringExtra("ruang");
        String dosen=intent.getStringExtra("dosen");
        int requestCode=intent.getIntExtra("requestCode", 50000);
        MainActivity.NotificationHelper.show(context,
                matkul == null ? "Kuliah" : matkul,
                ruang == null ? "" : ruang,
                dosen == null ? "" : dosen,
                requestCode);

        // Schedule the same class for the following week.
        if (context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .getBoolean(MainActivity.KEY_ENABLED, false)) {
            int day=intent.getIntExtra("dayOfWeek", java.util.Calendar.SATURDAY);
            int hour=intent.getIntExtra("hour", 7);
            int minute=intent.getIntExtra("minute", 0);
            int mins=intent.getIntExtra("reminderMinutes", 30);
            MainActivity.AlarmScheduler.scheduleOne(context, requestCode, day, hour, minute, mins,
                    matkul == null ? "Kuliah" : matkul,
                    ruang == null ? "" : ruang,
                    dosen == null ? "" : dosen);
        }
    }
}
